<?php
ini_set('log_errors', 'On');
ini_set('error_log', 'log/errors.log'); // Ruta al archivo de log
error_reporting(E_ALL);  // Reportar todos los errores
?>