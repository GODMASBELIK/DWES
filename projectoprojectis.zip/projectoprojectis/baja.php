<?php
require_once 'DAO.php';
require_once 'Vehiculo.php';
include_once("conf.php");
// Cargar los vehículos desde el archivo JSON
$dao = new DAO('coches.json');
$vehiculos = $dao->listar();

// Buscar por matrícula si se envió el parámetro
$busqueda = isset($_GET['matricula']) ? $_GET['matricula'] : '';
if ($busqueda !== '') {
    $vehiculos = array_filter($vehiculos, function($vehiculo) use ($busqueda) {
        return stripos($vehiculo['matricula'], $busqueda) !== false;
    });
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Vehículos</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Listado de Vehículos</h1>

    <form method="GET" action="baja.php">
        <label for="matricula">Buscar por matrícula:</label>
        <input type="text" id="matricula" name="matricula" value="<?php echo htmlspecialchars($busqueda); ?>">
        <button type="submit">Buscar</button>
    </form>

    <form method="POST" action="procesarbaja.php">
        <table>
            <thead>
                <tr>
                    <th>Seleccionar</th>
                    <th>Matrícula</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Potencia</th>
                    <th>Velocidad Máxima</th>
                    <th>Imagen</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($vehiculos)): ?>
                    <tr>
                        <td colspan="8">No se encontraron vehículos</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($vehiculos as $vehiculo): ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="matriculas[]" value="<?php echo htmlspecialchars($vehiculo['matricula']); ?>">
                            </td>
                            <td><?php echo htmlspecialchars($vehiculo['matricula']); ?></td>
                            <td><?php echo htmlspecialchars($vehiculo['marca']); ?></td>
                            <td><?php echo htmlspecialchars($vehiculo['modelo']); ?></td>
                            <td><?php echo htmlspecialchars($vehiculo['potencia']); ?> CV</td>
                            <td><?php echo htmlspecialchars($vehiculo['velocidadMax']); ?> km/h</td>
                            <td>
                                <?php if (!empty($vehiculo['imagen'])): ?>
                                    <img src="<?php echo htmlspecialchars($vehiculo['imagen']); ?>" alt="Imagen de <?php echo htmlspecialchars($vehiculo['modelo']); ?>" style="max-width: 100px;">
                                <?php else: ?>
                                    No disponible
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="editar.php?matricula=<?php echo urlencode($vehiculo['matricula']); ?>">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <button type="submit">Dar de Baja Seleccionados</button>
    </form>
</body>
</html>