<?php
include_once("conf.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Vehículos</title>
    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body {
            background-color: rgb(205, 205, 205);
            font-family: Arial, sans-serif;
        }

        form {
            background-color: rgb(255, 255, 255);
            padding: 2em;
            margin: 2em auto;
            width: 40%;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .form-group {
            display: flex;
            justify-content: space-between;
            margin-bottom: 1em;
        }

        label {
            flex: 1;
            margin-right: 1em;
        }

        input {
            flex: 2;
            padding: 0.5em;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        input[type="file"] {
            flex: 2;
        }

        input[type="submit"] {
            width: 100%;
            padding: 0.7em;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        select {
            flex: 2;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <form action="procesar.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="matricula">Matrícula</label>
            <input type="text" id="matricula" name="matricula" required>
        </div>
        <div class="form-group">
            <label for="modelo">Modelo</label>
            <input type="text" id="modelo" name="modelo" required>
        </div>
        <div class="form-group">
            <label for="marca">Marca</label>
            <select name="marca" id="">
               <?php
               foreach(file('marcas_vehiculos.txt') as $line) {
             echo  "<option value=\"$line\">$line</option>";
             }
               ?>
            </select>
        </div>
        <div class="form-group">
            <label for="potencia">Potencia</label>
            <input type="number" id="potencia" name="potencia" required>
        </div>
        <div class="form-group">
            <label for="velocidad">Velocidad Máxima</label>
            <input type="number" id="velocidad" name="velocidad" required>
        </div>
        <div class="form-group">
            <label for="imagen">Imagen del Vehículo</label>
            <input type="file" id="imagen" name="imagen" accept="image/*">
        </div>
        <input type="submit" value="Enviar">
    </form>
</body>

</html>
