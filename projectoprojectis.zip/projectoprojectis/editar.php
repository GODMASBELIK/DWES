<?php
require_once 'DAO.php';
require_once 'Vehiculo.php';
require_once 'conf.php';
// Obtener la matrícula del vehículo a editar
if (isset($_GET['matricula'])) {
    $matricula = $_GET['matricula'];

    // Crear una instancia de DAO para obtener el vehículo
    $dao = new DAO('coches.json');
    $vehiculo = $dao->buscarPorMatricula($matricula);

    // Si no se encuentra el vehículo, redirigir
    if (!$vehiculo) {
        header('Location: index.php');
        exit;
    }
} else {
    header('Location: index.php');
    exit;
}

// Procesar el formulario de edición
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Crear el objeto Vehiculo con los datos del formulario
    $veh = new Vehiculo($_POST["matricula"], $_POST["marca"], $_POST["modelo"]);
    $veh->potencia = $_POST["potencia"];
    $veh->velocidadMax = $_POST["velocidadMax"];

    // Manejar la imagen subida
    $rutaDestino = $vehiculo['imagen']; // Mantener la imagen actual si no se sube una nueva

    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] == UPLOAD_ERR_OK) {
        $archivo = $_FILES['imagen'];
        $nombreArchivo = "{$veh->matricula}_" . $archivo['name'];
        $tipoArchivo = $archivo['type'];
        $tmpArchivo = $archivo['tmp_name'];
        $tamañoArchivo = $archivo['size'];

        $directorioDestino = 'img/';
        if (!is_dir($directorioDestino)) {
            mkdir($directorioDestino, 0777, true); // Crear el directorio si no existe
        }

        // Ruta completa donde se guardará la imagen
        $rutaDestino = $directorioDestino . basename($nombreArchivo);

        $tiposPermitidos = ['image/jpeg', 'image/png', 'image/jpg'];
        if (in_array($tipoArchivo, $tiposPermitidos)) {
            $maxTamaño = 2 * 1024 * 1024; // 2MB en bytes
            if ($tamañoArchivo <= $maxTamaño) {
                if (move_uploaded_file($tmpArchivo, $rutaDestino)) {
                    echo "Imagen subida correctamente.";
                } else {
                    echo "Error al mover el archivo.";
                }
            } else {
                echo "El archivo es demasiado grande. El tamaño máximo permitido es 2MB.";
            }
        } else {
            echo "Tipo de archivo no permitido. Solo se aceptan imágenes JPG, PNG.";
        }
    }

    // Actualizar la ruta de la imagen en el objeto Vehiculo
    $veh->imgPath = $rutaDestino;

    // Actualizar el vehículo
    if ($dao->editar($matricula, $veh)) {
        // Redirigir a la página de listado o mostrar mensaje de éxito
        header('Location: baja.php');
        exit;
    } else {
        // Si no se actualizó correctamente, mostrar error
        echo "<p>Error al guardar los cambios.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Vehículo</title>
    <style>
        form {
            max-width: 600px;
            margin: 0 auto;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
        button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        .img-preview {
            max-width: 100px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h1>Editar Vehículo</h1>

    <form method="POST" action="" enctype="multipart/form-data">
        <label for="matricula">Matrícula:</label>
        <input type="text" id="matricula" name="matricula" value="<?php echo htmlspecialchars($vehiculo['matricula']); ?>" readonly>

        <label for="modelo">Modelo:</label>
        <input type="text" id="modelo" name="modelo" value="<?php echo htmlspecialchars($vehiculo['modelo']); ?>">

        <label for="marca">Marca:</label>
        <input type="text" id="marca" name="marca" value="<?php echo htmlspecialchars($vehiculo['marca']); ?>">

        <label for="potencia">Potencia (CV):</label>
        <input type="number" id="potencia" name="potencia" value="<?php echo htmlspecialchars($vehiculo['potencia']); ?>">

        <label for="velocidadMax">Velocidad Máxima (km/h):</label>
        <input type="number" id="velocidadMax" name="velocidadMax" value="<?php echo htmlspecialchars($vehiculo['velocidadMax']); ?>">

        <label for="imagen">Imagen (si desea cambiarla):</label>
        <input type="file" id="imagen" name="imagen">

        <?php if (!empty($vehiculo['imagen'])): ?>
            <div>
                <label>Imagen Actual:</label>
                <img src="<?php echo htmlspecialchars($vehiculo['imagen']); ?>" alt="Imagen actual" class="img-preview">
            </div>
        <?php endif; ?>

        <button type="submit">Guardar Cambios</button>
    </form>

    <p><a href="baja.php">Volver al listado</a></p>
</body>
</html>
