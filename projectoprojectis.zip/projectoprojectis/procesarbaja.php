<?php
require 'PHPMailer-master/vendor/autoload.php'; // Asegúrate de tener PHPMailer instalado y autoload incluido
require_once 'DAO.php';
require_once("conf.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$dao = new DAO('coches.json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['matriculas'])) {
    $matriculas = $_POST['matriculas'];

    $vehiculosEliminados = [];
    $dao = new DAO();

    foreach ($matriculas as $matricula) {
        if ($dao->quitar($matricula)) {
            $vehiculosEliminados[] = $matricula;
        }
    }

    $logFile = 'log/bajas.log';
    $logMessage = date('Y-m-d H:i:s') . " - Vehículos eliminados: " . implode(', ', $vehiculosEliminados) . "\n";
    file_put_contents($logFile, $logMessage, FILE_APPEND);

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'Alexandrisman18@gmail.com'; 
        $mail->Password = 'midy cjmy lyar qtvw'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        $mail->setFrom('Alexandrisman18@gmail.com', 'auto-reply');

        $mensajeObj = [
            'destinatario' => ['Alexandrisman18@gmail.com'], 
            'adjuntos' => [],
            'asunto' => 'Vehiculos eliminados',
            'cuerpo' => 'Se han dado de baja los siguientes vehículos: ' . implode(', ', $vehiculosEliminados)
        ];

        foreach ($mensajeObj['destinatario'] as $dest) {
            $mail->addAddress($dest);
        }

        foreach ($mensajeObj['adjuntos'] as $adjunto) {
            $mail->addAttachment($adjunto);
        }

        // Contenido del correo
        $mail->isHTML(true);
        $mail->Subject = $mensajeObj['asunto'];
        $mail->Body = $mensajeObj['cuerpo'];

        // Enviar el correo
        $mail->send();
        echo "Mensaje enviado con éxito.\n";
    } catch (Exception $e) {
        echo "Error al enviar el mensaje: {$mail->ErrorInfo}\n";
    }

    // Mostrar vehículos eliminados
    echo "<p>Los siguientes vehículos han sido dados de baja:</p>";
    echo "<ul>";
    foreach ($vehiculosEliminados as $matricula) {
        echo "<li>" . htmlspecialchars($matricula) . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>No se seleccionaron vehículos para eliminar.</p>";
}
?>
